package training;

public class replaceTest {

	public static void main(String[] args) {
		String S1="Selenium";
		System.out.println(S1.replace("e", "6"));	
		
		

	}

}
